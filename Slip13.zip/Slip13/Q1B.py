import numpy as np

array = [3, 1, 4, 1, 5, 9, 2, 6, 5, 3, 5]
np_array = np.array(array)

max_value = np.max(np_array)
min_value = np.min(np_array)

print("Maximum value:", max_value)
print("Minimum value:", min_value)
