import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv('iris.csv')

petal_length = df['petal_length']
petal_width = df['petal_width']

plt.figure(figsize=(8, 6))
plt.scatter(petal_length, petal_width, color='blue', edgecolor='black')

plt.xlabel('Petal Length (cm)')
plt.ylabel('Petal Width (cm)')
plt.title('Relationship between Petal Length and Petal Width')

plt.grid(True)
plt.show()
