<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chess Board</title>
    <style>
        table {
            border-collapse: collapse;
            margin: 20px auto;
        }
        td {
            width: 50px;
            height: 50px;
        }
        .white {
            background-color: #f0d9b5;
        }
        .black {
            background-color: #b58863;
        }
    </style>
</head>
<body>
    <table border="1">
    <?php
        $size = 8; // Size of the chess board (8x8)
        for ($row = 1; $row <= $size; $row++) {
            echo "<tr>";
            for ($col = 1; $col <= $size; $col++) {
                // Alternate between black and white squares
                $color = ($row + $col) % 2 == 0 ? 'white' : 'black';
                echo "<td class='$color'></td>";
            }
            echo "</tr>";
        }
        ?>
    </table>
</body>
</html>
