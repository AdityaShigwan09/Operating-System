<?php
$array = array("sagar" => "31", "vicky" => "41", "Leena" => "39", "Ramesh" => "40");

asort($array);
echo "Ascending order sort by value:\n";
print_r($array);

ksort($array);
echo "\nAscending order sort by key:\n";
print_r($array);

$array = array("sagar" => "31", "vicky" => "41", "Leena" => "39", "Ramesh" => "40");

arsort($array);
echo "\nDescending order sorting by value:\n";
print_r($array);

krsort($array);
echo "\nDescending order sorting by key:\n";
print_r($array);
?>
