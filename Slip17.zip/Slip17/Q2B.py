import pandas as pd

data = {
    'Name': ['Alice', 'Bob', 'Charlie', 'David', 'Eva', 
             'Frank', 'Grace', 'Hannah', 'Ian', 'Jack'],
    'Age': [28, 34, 25, 45, 30, 
            32, 29, 31, 35, 40],
    'Salary': [70000, 80000, 60000, 120000, 90000, 
               95000, 72000, 85000, 78000, 110000],
    'Department': ['HR', 'Finance', 'IT', 'Marketing', 'Sales', 
                   'IT', 'HR', 'Finance', 'Sales', 'Marketing']
}

df = pd.DataFrame(data)

print(df)
