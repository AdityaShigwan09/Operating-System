import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv('iris.csv')

feature_x = df['petal_length']
feature_y = df['petal_width']

plt.figure(figsize=(10, 6))
plt.scatter(feature_x, feature_y, c=df['species'].astype('category').cat.codes, cmap='viridis', edgecolor='k')

plt.xlabel('Petal Length (cm)')
plt.ylabel('Petal Width (cm)')
plt.title('Scatter Plot of Petal Length vs. Petal Width')

plt.colorbar(ticks=range(len(df['species'].unique())), label='Species')
plt.clim(-0.5, len(df['species'].unique()) - 0.5)
plt.xticks(ticks=range(0, 8))
plt.yticks(ticks=range(0, 3))

plt.grid()
plt.show()
