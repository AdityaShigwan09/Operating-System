import pandas as pd
import numpy as np

data = {
    'Name': ['Alice', 'Bob', 'Charlie', 'David', 'Eva', 'Frank', 'Grace', 'Hannah', 'Ian', 'Jack'],
    'Age': [20, 22, 19, 21, 20, 23, 22, 24, 19, 21],
    'Percentage': [85.6, 90.4, 76.3, 88.5, 92.1, 79.8, 84.2, 91.5, 78.0, 87.0]
}

df = pd.DataFrame(data)

print("Original DataFrame:\n", df)

print("\nShape of DataFrame:", df.shape)
print("Number of Rows and Columns:", df.shape[0], "rows,", df.shape[1], "columns")
print("\nData Types:\n", df.dtypes)
print("\nFeature Names (Columns):", df.columns.tolist())
print("\nDescription of the DataFrame:\n", df.describe())

new_data = {
    'Name': ['Alice', 'Bob', np.nan, 'Grace', 'Jack'],
    'Age': [20, 22, 20, np.nan, 21],
    'Percentage': [85.6, 90.4, np.nan, 84.2, np.nan]
}

df_new = pd.DataFrame(new_data)

df = pd.concat([df, df_new], ignore_index=True)

df['Remarks'] = ""

print("\nUpdated DataFrame with duplicates, missing values, and a 'Remarks' column:\n", df)
