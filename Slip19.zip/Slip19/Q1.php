<?php
$bigString = readline("Enter a sentence: ");
$smallString = readline("Enter a word: ");

$deletePos = (int)readline("Enter the position to start deletion: ");
$deleteLen = (int)readline("Enter the number of characters to delete: ");
$bigStringAfterDelete = substr_replace($bigString, '', $deletePos, $deleteLen);
echo "\nString after deletion: $bigStringAfterDelete\n";

$insertPos = (int)readline("Enter the position to insert the word: ");
$bigStringAfterInsert = substr_replace($bigString, $smallString, $insertPos, 0);
echo "\nString after insertion: $bigStringAfterInsert\n";

$replacePos = (int)readline("Enter the position to start replacing: ");
$replaceLen = (int)readline("Enter the number of characters to replace: ");
$bigStringAfterReplace = substr_replace($bigString, $smallString, $replacePos, $replaceLen);
echo "\nString after replacement: $bigStringAfterReplace\n";
?>
